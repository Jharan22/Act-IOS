import UIKit

//Una vez creado el proyecto diseña la clase Persona que contega dos métodos:

//El primero "Saludar" que reciba el parámetro nombre y regrese el mensaje el nombre más el texto "mucho gusto".

class Persona {
    var nombre = ""
    var mucho_gusto = ""
    
    init(nombre:String, mucho_gusto:String){
        self.nombre = nombre
        self.mucho_gusto = mucho_gusto
    }
}


//El segundo método "Caminar" que reciba como parámetro un tipo de dato Int y regrese un tipo de dato String indicando el número de pasos caminados.

class Caminar{
    var entero = "0"
    
    init(entero:String){
        self.entero = entero
    }
}

var texto = Persona(nombre:"Kevin ", mucho_gusto:"Mucho gusto")
var caminata = Caminar(entero: "10")

print("Hola \(texto.nombre)")
print("\(texto.mucho_gusto)")
print("Caminaste \(caminata.entero) pasos")


//Para el tema Struct, diseña el struct Pantalla, la cual recibirá como parámetros el ancho y alto de una pantalla como tipo de datos Int con un constructor para inicializar la estructura.

struct Pantalla{
    var alto:Int
    var ancho:Int
    
    
    init(alto:Int, ancho:Int)
    {
        self.alto = alto
        self.ancho = ancho
    }
    
    func resolucion() -> (Int,Int) {
        return (self.alto, self.ancho)
    }
}

var high_definition = Pantalla(alto: 1024, ancho: 768)
var vga = Pantalla(alto: 480, ancho: 640)

high_definition.resolucion()
vga.resolucion()



//Para el tema extensión, diseña una extensión del tipo de dato Int que represente las horas y que pueda regresar los segundos correspondientes (puedes utilizar una función o una variable computada) y diseña una extensión del tipo de dato String que represente un día de la semana y regrese el número correspondiente iniciado con Domingo=1 y finalizando con Sábado=7

extension Int{
    func horas() -> Int{
        return self*24*60
    }
}

//horas a segundos
3.horas()

extension Int{
    func domingo() -> String{
        return "Domingo"
    }
    func lunes() -> String{
        return "Lunes"
    }
    func martes() -> String{
        return "Martes"
    }
    func miercoles() -> String{
        return "Miércoles"
    }
    func jueves() -> String{
        return "Jueves"
    }
    func viernes() -> String{
        return "Viernes"
    }
    func sabado() -> String{
        return "Sábado"
    }
}

1.domingo()
2.lunes()
3.martes()
4.miercoles()
5.jueves()
6.viernes()
7.sabado()



//Para el tema Optional, diseña una variable optional para recibir el tipo de dato Int en caso de que exista.
//Para la colecciòn -let dias =["GDL":120, "PUE":300,"MTY":100,"CDMX":200], diseña una variable opcional para recibir el valor de días ["DF"]


let dias = ["GDL":120, "PUE":300,"MTY":100,"CDMX":200]
let existe:Int?

existe = dias["DF"]

if let tmp = dias["DF"]{
    print("Si existe")
}else{
    print("No existe")
}


//Para la colecciòn -let dias =["GDL":120, "PUE":300,"MTY":100,"CDMX":200], diseña una variable opcional para recibir el valor de días ["DF"]

let otros_dias = ["GDL":120, "PUE":300,"MTY":100,"CDMX":200, "DF":400]
let existira:Int?

existira = otros_dias["DF"]

if let tmp2 = otros_dias["DF"]{
    print("Si existe")
}else{
    print("No existe")
}
